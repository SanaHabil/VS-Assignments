function hide(element) {
    element.remove();
}

function logout(element) {
    element.innerText="Log out";
}

function messageuser(){
    alert("Ninja was liked");
}

