from crypt import methods
from flask import Flask, render_template, redirect, request
# import the class from userS.py
from user import User
app = Flask(__name__)

@app.route('/users')
def index():
    users = User.get_all()
    print(users)
    return render_template("index.html", all_users = users)

@app.route('/add_new_user')
def add_new_user():
    return render_template("add_new_user.html")

@app.route('/user/new', methods=['POST'])    
def create():
    User.create_user(request.form)
    return redirect('/users')


if __name__ == "__main__":
    app.run(debug=True)