def print_and_return(num_list):
    print(num_list[0])
    return(num_list[1])

list = [1,4]
result = print_and_return(list)
print(result)  